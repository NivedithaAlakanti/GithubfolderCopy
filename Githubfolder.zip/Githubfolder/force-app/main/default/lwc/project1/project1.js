import { LightningElement } from 'lwc';

export default class Project1 extends LightningElement {}